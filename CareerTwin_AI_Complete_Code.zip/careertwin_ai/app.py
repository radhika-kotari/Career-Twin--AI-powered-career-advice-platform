from flask import Flask, render_template, request, jsonify
from werkzeug.utils import secure_filename
import os, re
from pypdf import PdfReader

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024
app.config["UPLOAD_FOLDER"] = "uploads"
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
ALLOWED_EXTENSIONS = {"pdf", "txt"}

CAREERS = [
    {
        "title": "Data Scientist",
        "category": "Data & AI",
        "description": "Use data, statistics, and machine learning to discover patterns and support decisions.",
        "skills": ["python", "statistics", "sql", "machine learning", "data analysis", "pandas", "visualization"],
        "roadmap": ["Strengthen Python and SQL", "Learn statistics and exploratory data analysis", "Build a pandas data-cleaning project", "Learn core machine-learning models", "Publish a portfolio project with a clear README"]
    },
    {
        "title": "Data Analyst",
        "category": "Data & AI",
        "description": "Turn raw data into useful insights using queries, dashboards, and clear communication.",
        "skills": ["sql", "excel", "python", "power bi", "tableau", "data analysis", "visualization"],
        "roadmap": ["Practice SQL queries and joins", "Learn spreadsheet analysis", "Build a Power BI dashboard", "Practice data cleaning with Python", "Present two projects with business insights"]
    },
    {
        "title": "Frontend Developer",
        "category": "Software Development",
        "description": "Build accessible, responsive interfaces and interactive web experiences.",
        "skills": ["html", "css", "javascript", "react", "ui", "ux", "web development"],
        "roadmap": ["Master semantic HTML and CSS layouts", "Practice JavaScript fundamentals", "Build a responsive multi-page website", "Learn React components and state", "Deploy a polished portfolio project"]
    },
    {
        "title": "Backend Developer",
        "category": "Software Development",
        "description": "Create APIs, application logic, databases, and reliable server-side systems.",
        "skills": ["python", "flask", "django", "sql", "api", "rest api", "database", "git"],
        "roadmap": ["Strengthen Python fundamentals", "Learn HTTP and REST API concepts", "Build a Flask application", "Practice SQL and database design", "Add authentication, tests, and deployment"]
    },
    {
        "title": "AI / Machine Learning Engineer",
        "category": "Data & AI",
        "description": "Develop and evaluate models that learn patterns and support intelligent applications.",
        "skills": ["python", "machine learning", "deep learning", "statistics", "numpy", "pandas", "ai"],
        "roadmap": ["Build strong Python and math foundations", "Learn NumPy, pandas, and visualization", "Study supervised and unsupervised learning", "Train and evaluate a model on a real dataset", "Build a small AI-powered application"]
    },
    {
        "title": "UI/UX Designer",
        "category": "Design",
        "description": "Research user needs and design intuitive, accessible digital products.",
        "skills": ["figma", "ui", "ux", "wireframing", "prototyping", "design", "communication"],
        "roadmap": ["Study usability and accessibility basics", "Practice user flows and wireframes", "Create a clickable Figma prototype", "Run simple usability tests", "Document a complete design case study"]
    },
    {
        "title": "Cybersecurity Analyst",
        "category": "Security",
        "description": "Help protect systems by identifying risks, monitoring activity, and responding to incidents.",
        "skills": ["networking", "linux", "security", "python", "risk", "cloud", "incident response"],
        "roadmap": ["Learn networking and operating-system basics", "Practice Linux and scripting", "Study common vulnerabilities and defensive controls", "Use a legal lab to practice log analysis", "Document a defensive security project"]
    },
    {
        "title": "Cloud / DevOps Engineer",
        "category": "Cloud & Infrastructure",
        "description": "Automate delivery and help applications run reliably in cloud environments.",
        "skills": ["linux", "git", "docker", "cloud", "aws", "azure", "ci/cd", "python"],
        "roadmap": ["Learn Linux, Git, and networking", "Understand cloud fundamentals", "Containerize a small application", "Create a basic CI/CD workflow", "Deploy and monitor a project"]
    }
]

SKILL_ALIASES = {
    "js": "javascript", "powerbi": "power bi", "ml": "machine learning",
    "ai/ml": "machine learning", "machine-learning": "machine learning",
    "html5": "html", "css3": "css", "postgresql": "sql", "mysql": "sql"
}

def normalize_skills(value):
    if isinstance(value, list):
        raw = value
    else:
        raw = re.split(r"[,;\n|]+", value or "")
    result = []
    for item in raw:
        skill = item.strip().lower()
        skill = SKILL_ALIASES.get(skill, skill)
        if skill and skill not in result:
            result.append(skill)
    return result

def recommend_careers(skills, interests="", education="", goal=""):
    combined = " ".join([interests or "", education or "", goal or ""]).lower()
    results = []
    for career in CAREERS:
        matched = [s for s in career["skills"] if s in skills or s in combined]
        score = round((len(set(matched)) / max(len(career["skills"]), 1)) * 100)
        # Keep suggestions useful even when the profile has few skills.
        if score > 0:
            results.append({**career, "score": min(score, 98), "matched": matched})
    results.sort(key=lambda item: (item["score"], len(item["matched"])), reverse=True)
    if not results:
        results = [
            {**CAREERS[1], "score": 35, "matched": []},
            {**CAREERS[2], "score": 30, "matched": []},
            {**CAREERS[0], "score": 25, "matched": []}
        ]
    return results[:4]

def extract_resume_text(path, ext):
    if ext == "txt":
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    reader = PdfReader(path)
    return "\n".join(page.extract_text() or "" for page in reader.pages)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/recommend", methods=["POST"])
def recommend():
    data = request.get_json(silent=True) or {}
    skills = normalize_skills(data.get("skills", ""))
    interests = str(data.get("interests", ""))[:1000]
    education = str(data.get("education", ""))[:300]
    goal = str(data.get("goal", ""))[:500]
    careers = recommend_careers(skills, interests, education, goal)
    return jsonify({
        "careers": careers,
        "profile": {"skills": skills, "education": education, "goal": goal},
        "note": "These are guidance suggestions based on the information entered, not a guarantee of job outcomes."
    })

@app.route("/api/roadmap", methods=["POST"])
def roadmap():
    data = request.get_json(silent=True) or {}
    title = str(data.get("title", "Data Analyst"))
    days = int(data.get("days", 30))
    days = days if days in (30, 60, 90) else 30
    career = next((c for c in CAREERS if c["title"].lower() == title.lower()), CAREERS[1])
    tasks = career["roadmap"]
    weeks = max(1, days // 7)
    plan = []
    for i, task in enumerate(tasks):
        start = round(i * days / len(tasks)) + 1
        end = min(days, round((i + 1) * days / len(tasks)))
        plan.append({"period": f"Days {start}–{end}", "task": task})
    return jsonify({"title": career["title"], "days": days, "plan": plan})

@app.route("/api/resume", methods=["POST"])
def resume():
    uploaded = request.files.get("resume")
    if not uploaded or not uploaded.filename:
        return jsonify({"error": "Choose a PDF or TXT resume first."}), 400
    filename = secure_filename(uploaded.filename)
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext not in ALLOWED_EXTENSIONS:
        return jsonify({"error": "Please upload a PDF or TXT file."}), 400
    path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    uploaded.save(path)
    try:
        content = extract_resume_text(path, ext)
    except Exception:
        content = ""
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if not content.strip():
        return jsonify({"error": "I couldn't read text from this file. Try a text-based PDF or TXT file."}), 400

    lower = content.lower()
    all_skills = sorted({s for c in CAREERS for s in c["skills"]})
    found = [s for s in all_skills if re.search(r"(?<!\w)" + re.escape(s) + r"(?!\w)", lower)]
    missing = [s for s in ["python", "sql", "javascript", "git", "communication", "project"] if s not in lower]
    recommendations = []
    if not re.search(r"\b(project|projects)\b", lower):
        recommendations.append("Add 2–3 relevant projects with your role, tools, and measurable outcomes.")
    if not re.search(r"\b(internship|experience|work experience)\b", lower):
        recommendations.append("Add internships, volunteering, or practical experience if available.")
    if not re.search(r"\b(education|bachelor|b\.tech|degree|college|university)\b", lower):
        recommendations.append("Make your education section easy to find.")
    if not re.search(r"\b(github|portfolio|linkedin)\b", lower):
        recommendations.append("Include relevant portfolio, GitHub, or professional profile links.")
    recommendations.append("Tailor the skills and project descriptions to each role you apply for.")
    return jsonify({
        "characters": len(content),
        "skills": found[:20],
        "missing_skills_to_consider": missing,
        "recommendations": recommendations,
        "disclaimer": "This is a basic text-based review, not a formal ATS score. Verify every suggestion before editing your resume."
    })

@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()
    if not message:
        return jsonify({"reply": "Tell me what career question you would like help with."})
    q = message.lower()
    if any(w in q for w in ["resume", "cv"]):
        reply = "For a stronger resume, use clear sections, action verbs, relevant skills, and 2–3 projects with outcomes. Keep formatting consistent and tailor it to the role."
    elif any(w in q for w in ["interview", "interviewing"]):
        reply = "Start by preparing a 60-second introduction, 3 project stories, core technical concepts, and examples of teamwork or problem-solving. Practice answering with the STAR method."
    elif any(w in q for w in ["data scientist", "machine learning", " ai "]):
        reply = "A practical AI/ML path is Python → NumPy/pandas → statistics → data visualization → machine-learning basics → model evaluation → a documented end-to-end project."
    elif any(w in q for w in ["frontend", "web developer", "website"]):
        reply = "A frontend path is semantic HTML → responsive CSS → JavaScript → accessibility → Git → a framework such as React → deploy 2–3 polished projects."
    elif any(w in q for w in ["data analyst", "analytics", "power bi"]):
        reply = "For data analytics, focus on SQL, spreadsheets, data cleaning, visualization, and communicating insights. Build a dashboard project and explain the decisions its findings support."
    elif any(w in q for w in ["roadmap", "plan", "where do i start"]):
        reply = "Choose one target role, review 5 job descriptions, list recurring skills, learn the top two gaps, and build a small project. Use the Roadmap tool to create a 30-, 60-, or 90-day plan."
    else:
        reply = "I can help you compare career paths, identify skills to learn, improve a resume, prepare for interviews, or plan projects. Share your education, current skills, and the role you are considering for more specific guidance."
    return jsonify({"reply": reply})

@app.errorhandler(413)
def too_large(_error):
    return jsonify({"error": "File is too large. Please upload a file smaller than 5 MB."}), 413

if __name__ == "__main__":
    app.run(debug=True)
