const $ = (selector, root=document) => root.querySelector(selector);
const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];
const toast = (message) => {
  const el = $("#toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(window.toastTimeout);
  window.toastTimeout = setTimeout(() => el.classList.remove("show"), 3000);
};
const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, ch => ({
  "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
}[ch]));
const showPage = (id) => {
  $$(".page").forEach(page => page.classList.toggle("active-page", page.id === id));
  $$(".nav-item").forEach(item => item.classList.toggle("active", item.dataset.target === id));
  const active = $(`.nav-item[data-target="${id}"]`);
  $("#breadcrumbCurrent").textContent = active ? active.textContent.trim() : "Overview";
  $("#sidebar").classList.remove("open");
  window.scrollTo({top:0, behavior:"smooth"});
};
$$("[data-target]").forEach(button => button.addEventListener("click", () => showPage(button.dataset.target)));
$("#mobileMenu").addEventListener("click", () => $("#sidebar").classList.toggle("open"));

async function postJSON(url, data) {
  const response = await fetch(url, {
    method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(data)
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "Something went wrong. Please try again.");
  return result;
}
function loading(target, message="Working on your request…") {
  $(target).innerHTML = `<div class="loading">${escapeHtml(message)}</div>`;
}
function renderCareers(data) {
  const target = $("#careerResults");
  const cards = data.careers.map((career, i) => `
    <article class="career-result">
      <div class="career-result-top">
        <div class="career-icon">${["✳","⌘","↗","◎"][i%4]}</div>
        <div><h3>${escapeHtml(career.title)}</h3><span class="career-category">${escapeHtml(career.category)}</span></div>
        <span class="match-pill">${career.score}% skill overlap</span>
      </div>
      <p>${escapeHtml(career.description)}</p>
      <div class="skill-tags">${(career.matched.length ? career.matched : ["Explore fundamentals"]).slice(0,5).map(s=>`<span class="skill-tag">${escapeHtml(s)}</span>`).join("")}</div>
      <button class="small-button roadmap-shortcut" data-title="${escapeHtml(career.title)}">Build a roadmap for this role →</button>
    </article>`).join("");
  target.innerHTML = `<div class="result-heading"><div><h2>Your career directions</h2><p>Use these as starting points to research roles and compare real job descriptions.</p></div></div><div class="career-results">${cards}</div><p class="privacy-note" style="margin-top:12px">${escapeHtml(data.note)}</p>`;
  $$(".roadmap-shortcut", target).forEach(button => button.addEventListener("click", () => {
    const title = button.dataset.title;
    const select = $("#roadmapTitle");
    const option = [...select.options].find(o => o.text.toLowerCase() === title.toLowerCase());
    if (option) select.value = option.value;
    showPage("roadmap");
    $("#roadmapTitle").focus();
  }));
}
$("#careerForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  loading("#careerResults", "Finding career directions that may fit your profile…");
  try {
    const data = await postJSON("/api/recommend", Object.fromEntries(form.entries()));
    renderCareers(data);
  } catch(error) { $("#careerResults").innerHTML = `<div class="error-message">${escapeHtml(error.message)}</div>`; }
});

$("#resumeFile").addEventListener("change", event => {
  const file = event.target.files[0];
  $("#fileLabel").textContent = file ? file.name : "Choose a file or drag it here";
});
$("#resumeForm").addEventListener("submit", async event => {
  event.preventDefault();
  const file = $("#resumeFile").files[0];
  if (!file) return toast("Choose a PDF or TXT resume first.");
  const data = new FormData();
  data.append("resume", file);
  loading("#resumeResults", "Reading your resume and checking its content…");
  try {
    const response = await fetch("/api/resume", {method:"POST", body:data});
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Could not analyze the file.");
    const skills = result.skills.length ? result.skills : ["No recognized skills found"];
    $("#resumeResults").innerHTML = `
      <div class="result-heading"><div><h2>Your resume review</h2><p>Text extracted: ${result.characters} characters</p></div></div>
      <div class="analysis-block"><h3>Skills detected</h3><div class="tag-list">${skills.map(s=>`<span>${escapeHtml(s)}</span>`).join("")}</div></div>
      <div class="analysis-block"><h3>Skills you could consider highlighting</h3><div class="tag-list">${result.missing_skills_to_consider.map(s=>`<span class="missing">${escapeHtml(s)}</span>`).join("")}</div></div>
      <div class="analysis-block"><h3>Suggestions to strengthen your resume</h3><ul>${result.recommendations.map(s=>`<li>${escapeHtml(s)}</li>`).join("")}</ul><p class="privacy-note">${escapeHtml(result.disclaimer)}</p></div>`;
  } catch(error) { $("#resumeResults").innerHTML = `<div class="error-message">${escapeHtml(error.message)}</div>`; }
});

$("#roadmapForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  loading("#roadmapResults", "Building your learning plan…");
  try {
    const data = await postJSON("/api/roadmap", Object.fromEntries(form.entries()));
    $("#roadmapResults").innerHTML = `
      <div class="result-heading"><div><h2>${escapeHtml(data.days)}-day roadmap</h2><p>A practical starter plan for becoming a ${escapeHtml(data.title)}.</p></div></div>
      <div class="roadmap-timeline">${data.plan.map(item=>`<div class="timeline-item"><div class="timeline-period">${escapeHtml(item.period)}</div><div class="timeline-line"><span class="timeline-dot"></span></div><div class="timeline-content"><strong>${escapeHtml(item.task)}</strong><p>Set aside focused practice time, keep notes, and save your work in a portfolio or GitHub repository.</p></div></div>`).join("")}</div>
      <p class="privacy-note" style="margin-top:12px">Tip: adjust the pace to your schedule. This roadmap is a suggested starting point, not a guarantee of employment.</p>`;
  } catch(error) { $("#roadmapResults").innerHTML = `<div class="error-message">${escapeHtml(error.message)}</div>`; }
});

function addMessage(text, type) {
  const messages = $("#chatMessages");
  const row = document.createElement("div");
  row.className = `message ${type === "user" ? "user-message" : "assistant-message"}`;
  if (type === "assistant") row.innerHTML = `<div class="message-avatar">✦</div><div class="message-bubble">${escapeHtml(text).replace(/\n/g,"<br>")}</div>`;
  else row.innerHTML = `<div class="message-bubble">${escapeHtml(text)}</div>`;
  messages.appendChild(row);
  messages.scrollTop = messages.scrollHeight;
}
async function sendChat(message) {
  addMessage(message, "user");
  const input = $("#chatInput");
  input.value = "";
  input.disabled = true;
  try {
    const data = await postJSON("/api/chat", {message});
    addMessage(data.reply, "assistant");
  } catch(error) { addMessage(error.message, "assistant"); }
  finally { input.disabled = false; input.focus(); }
}
$("#chatForm").addEventListener("submit", event => {
  event.preventDefault();
  const message = $("#chatInput").value.trim();
  if (message) sendChat(message);
});
$$("[data-prompt]").forEach(button => button.addEventListener("click", () => sendChat(button.dataset.prompt)));
