# CareerTwin AI

A responsive career guidance web app built with Python Flask, HTML, CSS, and JavaScript.

## Features
- Career recommendations based on entered education, skills, interests, and goals
- PDF/TXT resume text review with skill detection and improvement suggestions
- 30-, 60-, and 90-day career learning roadmaps
- Career assistant with starter guidance for common questions
- Responsive navigation and mobile-friendly interface

## Requirements
- Python 3.10 or newer
- VS Code (recommended)

## Run in VS Code

1. Extract the ZIP file and open the `careertwin_ai` folder in VS Code.
2. Open the VS Code terminal (**Terminal → New Terminal**).
3. Create a virtual environment:

   **Windows**
   ```bash
   py -m venv .venv
   .venv\Scripts\activate
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

4. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```

5. Start the website:
   ```bash
   python app.py
   ```

6. Open the local address printed in the terminal, usually `http://127.0.0.1:5000`.

## Project structure

```text
careertwin_ai/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   └── script.js
└── uploads/   # created automatically; temporary resume files are removed after analysis
```

## Important notes
- The career engine and chat responses are rule-based starter implementations. They do not call a generative AI model yet.
- Resume review is a lightweight text scan, not a certified ATS score. Scanned/image-only PDFs may not contain extractable text.
- This starter version has no login or database. User entries are processed for the request and are not saved as a profile.
- For public deployment, turn off Flask debug mode, add authentication/rate limiting, validate uploads carefully, and use secure hosting.
- Google Fonts are loaded from an external service; the rest of the frontend assets are local.
